import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner (System.in);




        System.out.print("How many numbers do you want to enter? ");
        int tal = scan.nextInt();
        smallestLargest(tal);
    }
    public static void smallestLargest(int tal){
        int smallest =0;
        int largest= 0;
        int temp = 0;
        for (int i = 1; i <=tal ; i++) {
            Scanner input = new Scanner(System.in);
            System.out.print("Enter a Number: ");
            int number = input.nextInt();
            System.out.println("Number " + i + ": " + number);

        }
            
    }
}

public class Main {

    public static void main(String[] args) {
        //klader printNumber metoden med parametere
	    printNumbers(15);
	    printNumbers(5);
    }
    //metoden tager int tal som parameter
    public static void printNumbers (int tal){
        //for lokke printer indtil <=tal.
        for (int i = 1; i <=tal; i++) {
            System.out.print("[" +i + "]");
        }
       // System.out.println();
    }
}

public class Stewie2 {

    public static void main(String[] args) {
        //laver en for lokke der køre 5 gange. (index 0)
        for (int i = 0; i <=4 ; i++) {
            printLinje();
            printTekst();
        }
    }


    //laver 2 staticske metoder som kan kaldes i samme klasse
    static void printLinje(){
        System.out.println("//////////////////////");
    }
    static void printTekst(){

        System.out.println("|| Victory is mine! ||");
    }
}

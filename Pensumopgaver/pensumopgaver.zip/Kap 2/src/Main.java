public class Main {

    public static void main(String[] args) {

        int tal = 7;
        //Denne loop holder styr på linje nummer. (printer antal linjer)
        for (int i = 0; i <= tal; i++) {
            //The inner for loop is used to keep track of the number of *'s we are printing

            //Denne loop holder styr på de numre der skal printes.
            for (int j = 1; j <= i; j++) {
                // printer 1 - 7 i indre lokke.
                System.out.print(i + " ");


            }
            //printer et tomt mellemrum efter hver tal.
            System.out.println();
        }
    }
}

